/**
 * Gurmeet & Sonam Wedding RSVP -> Google Sheets
 *
 * SETUP:
 * 1. Create a Google Sheet for RSVPs.
 * 2. In that Sheet, open Extensions > Apps Script.
 * 3. Replace the editor contents with this code and save.
 * 4. Deploy > New deployment > select "Web app".
 * 5. Execute as: Me. Who has access: Anyone.
 * 6. Deploy and copy the Web app URL ending in /exec.
 * 7. Paste that URL into index.html as RSVP_ENDPOINT.
 *
 * Do not put private guest information in a publicly shared spreadsheet.
 */
const SHEET_NAME = 'Wedding RSVPs';

function doPost(e) {
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    let sheet = ss.getSheetByName(SHEET_NAME);
    if (!sheet) {
      sheet = ss.insertSheet(SHEET_NAME);
      sheet.appendRow(['Submitted At', 'Guest Name', 'Attendance', 'Guest Count', 'Message']);
      sheet.setFrozenRows(1);
    }

    const p = (e && e.parameter) ? e.parameter : {};
    const name = String(p.guestName || '').trim().slice(0, 150);
    const attendance = String(p.attendance || '').trim().slice(0, 60);
    const count = String(p.guestCount || '').trim().slice(0, 10);
    const message = String(p.guestMessage || '').trim().slice(0, 1000);

    if (!name || !['Joyfully accepts', 'Regretfully declines'].includes(attendance)) {
      return ContentService.createTextOutput('Invalid RSVP');
    }

    sheet.appendRow([
      new Date(),
      safeCell_(name),
      safeCell_(attendance),
      safeCell_(count),
      safeCell_(message)
    ]);
    return ContentService.createTextOutput('OK');
  } finally {
    lock.releaseLock();
  }
}

// Prevent user-entered values beginning with formula characters from being interpreted as formulas.
function safeCell_(value) {
  const s = String(value || '');
  return /^[=+\-@]/.test(s) ? "'" + s : s;
}
