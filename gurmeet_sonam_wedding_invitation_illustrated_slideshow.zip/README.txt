GURMEET & SONAM — WEDDING INVITATION WEBSITE

This is a custom wedding invitation inspired by the section order, burgundy/cream palette, illustrated-couple scenes, slideshow, countdown and RSVP experience of the reference invitation.

OPEN LOCALLY
1. Extract this ZIP into one folder.
2. Keep index.html, all scene images, GoogleAppsScript.gs and wedding-music.wav together.
3. Double-click index.html to preview in Chrome.

ILLUSTRATED IMAGES ONLY
The website uses four generated stylized 3D/CGI illustrations (scene-1.jpg to scene-4.jpg). No real couple photo is used in the website.

DETAILS INCLUDED
Groom: Gurmeet Singh
Groom's parents: Mr. Baldev Singh (Bobby) & Mrs. Pooja
Groom's grandparents: Mr. Subhash Chand & Mrs. Premlata
Bride: Sonam Kaur
Bride's parents: Mr. Manoj Kumar & Mrs. Anju Devi
Date: Tuesday, 1 December 2026
Lava: 11:00 AM | Lunch: 1:00 PM
Venue: Chander Nagar Recreation Club, Near Devika Tower, Chandra Nagar, Surya Nagar, Uttar Pradesh 201011
Special mention: Mehar Kapoor (Groom's Bathiji)
Inviting family: Navyar Family
Contacts: 9896090357 / 8295495890

FUNCTIONS
- Invitation opening animation and wax-seal style design
- Four-scene illustrated love-story slideshow with manual controls and autoplay
- Music play/pause control (browser may require a tap before playback)
- Countdown to 1 Dec 2026, 11:00 AM India time
- Map link, Add to Calendar, Share, and Copy Wedding Details
- RSVP form
- Optional voice wish recorder; the recording remains local and is NOT uploaded to Google Sheets
- Falling gold motifs and scroll reveal animations

RSVP TO GOOGLE SHEETS
The RSVP endpoint is intentionally a placeholder. To collect responses online, deploy GoogleAppsScript.gs as a Google Apps Script Web App, set access as appropriate, then replace PASTE_YOUR_GOOGLE_APPS_SCRIPT_WEB_APP_URL_HERE in index.html with the deployed Web App URL. Test with a sample RSVP before sharing the public invitation.

PUBLISH FOR FREE
You can host the folder using GitHub Pages. Upload all files to one repository and enable Pages in repository settings. Once published, share the public HTTPS link.

NOTE
The reference site's exact source code, licensed music and original artwork are not copied. This is a custom recreation of the visible layout and interactions using the couple's own details and newly generated illustrations. Music playback depends on the included file and browser settings.
